import rclpy
from rclpy.node import Node
import serial
import time
import sys
import termios
import tty

def getch():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

class SerialNode(Node):
    def __init__(self):
        super().__init__('serial_node')

        self.esp32_port = '/dev/ttyUSB0'  # Ajusta el puerto serie según tu configuración
        self.baud_rate = 115200

        try:
            self.ser = serial.Serial(self.esp32_port, self.baud_rate)
            time.sleep(2)  # Espera a que se establezca la conexión serial
            self.get_logger().info("Conexión serial establecida")
        except serial.SerialException:
            self.get_logger().error("Error al abrir el puerto serial")
            sys.exit(1)

        self.timer = self.create_timer(0.1, self.send_serial_data)

    def send_serial_data(self):
        command = getch()
        if command in ['w', 's', 'a', 'd', 'q']:
            self.ser.write(command.encode())
            self.get_logger().info(f"Enviado comando: {command}")

def main(args=None):
    rclpy.init(args=args)
    serial_node = SerialNode()
    try:
        rclpy.spin(serial_node)
    except KeyboardInterrupt:
        pass
    finally:
        serial_node.ser.close()
        serial_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()


